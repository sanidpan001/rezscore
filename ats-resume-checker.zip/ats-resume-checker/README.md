# RezScore — Free ATS Resume Score Checker

A production-ready, fully static **Astro** website for a free ATS resume score
checker. No signup, no watermark, no stored data — resume parsing and checks
run in the visitor's browser, AI scoring via the Fixoraa universal backend
(Groq `llama-3.1-8b-instant`).

**Brand:** RezScore (unique — not affiliated with fixoraa branding)

## Features

- Upload PDF (pdfjs-dist) / DOCX (mammoth) / TXT or paste resume text — parsed client-side
- AI overall score (0–100) + section-wise scores: Contact, Summary, Experience, Skills, Education
- Job-description match score with missing/found keyword chips
- ATS plain-text parse preview ("how a robot reads your resume")
- Formatting-killers detector (AI + heuristics) with severity warnings
- Weak-bullet list with one-click AI rewrites
- Metrics checker flagging bullets without numbers
- Role selector tailoring every AI prompt
- Before/after score delta via localStorage
- Bonus: LinkedIn headline generator (5 headlines, copy buttons)
- Exact ad placements: top 728×90 + bottom banner, responsive-scaled on mobile
- 1200+ word SEO guide, 6 FAQs with FAQPage JSON-LD, SoftwareApplication + Article schema

## Tech

Astro 4 (static output) + Tailwind CSS + Preact island (`client:only`).

## Local development

```bash
npm install
npm run dev      # http://localhost:4321
npm run build    # outputs to dist/
npm run preview
```

## Deploy to Cloudflare Pages

1. Push this folder to a GitHub repo.
2. Cloudflare dashboard → **Workers & Pages** → **Create** → **Pages** → connect the repo.
3. Build settings:
   - **Build command:** `npm run build`
   - **Build output directory:** `dist`
   - **Root directory:** repo root (or the folder, if monorepo)
   - Node version: 18+ (default is fine)
4. Deploy. Every push rebuilds automatically. Custom domain can be attached
   under Pages → Custom domains.

No adapter or SSR config needed — the site is 100% static; all AI calls run
from the visitor's browser.
