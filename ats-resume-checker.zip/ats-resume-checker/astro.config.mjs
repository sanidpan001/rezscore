import { defineConfig } from 'astro/config';
import tailwind from '@astrojs/tailwind';
import preact from '@astrojs/preact';

// Static output — deploy the `dist/` folder to Cloudflare Pages.
export default defineConfig({
  output: 'static',
  integrations: [
    tailwind(),
    preact({ compat: true }),
  ],
});
