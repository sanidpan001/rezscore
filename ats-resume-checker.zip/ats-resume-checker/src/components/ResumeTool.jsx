import { useState, useEffect, useRef } from 'preact/hooks';
import * as pdfjsLib from 'pdfjs-dist';
import workerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
import mammoth from 'mammoth';

const GROQ_URL = 'https://fixoraa-universal-backend.onrender.com/api/groq';
const GROQ_MODEL = 'llama-3.1-8b-instant';

const ROLES = [
  'Software Engineer',
  'Data Analyst',
  'Marketing',
  'Designer',
  'Finance',
  'Customer Support',
  'Other',
];

/* ---------------- helpers ---------------- */

async function callGroq(prompt) {
  const res = await fetch(GROQ_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: GROQ_MODEL, messages: [{ role: 'user', content: prompt }] }),
  });
  if (!res.ok) throw new Error(`AI service returned ${res.status}. Please try again in a moment.`);
  const data = await res.json();
  const content =
    data?.data?.choices?.[0]?.message?.content ??
    data?.choices?.[0]?.message?.content ??
    '';
  if (!content || !String(content).trim()) throw new Error('The AI returned an empty response. Please try again.');
  return String(content);
}

function parseJson(content) {
  const cleaned = String(content).replace(/```json|```/g, '').trim();
  const start = cleaned.indexOf('{');
  const end = cleaned.lastIndexOf('}');
  if (start === -1 || end === -1) throw new Error('Could not understand the AI response. Please try again.');
  return JSON.parse(cleaned.slice(start, end + 1));
}

function parseJsonArray(content) {
  const cleaned = String(content).replace(/```json|```/g, '').trim();
  const start = cleaned.indexOf('[');
  const end = cleaned.lastIndexOf(']');
  if (start === -1 || end === -1) throw new Error('Could not understand the AI response. Please try again.');
  return JSON.parse(cleaned.slice(start, end + 1));
}

async function copyText(text, done) {
  try {
    await navigator.clipboard.writeText(text);
  } catch (e) {
    const ta = document.createElement('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
  }
  if (done) done();
}

async function extractPdf(arrayBuffer) {
  pdfjsLib.GlobalWorkerOptions.workerSrc = workerUrl;
  const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
  let text = '';
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();
    text += content.items.map((it) => it.str).join(' ') + '\n';
  }
  return text;
}

async function extractDocx(arrayBuffer) {
  const result = await mammoth.extractRawText({ arrayBuffer });
  return result.value;
}

function scoreColor(s) {
  if (s >= 75) return '#0E9F6E';
  if (s >= 50) return '#B45309';
  return '#DC2626';
}

function scoreLabel(s) {
  if (s >= 85) return 'Excellent';
  if (s >= 75) return 'Strong';
  if (s >= 60) return 'Needs work';
  if (s >= 40) return 'Weak';
  return 'Critical';
}

/* ---------------- small components ---------------- */

function Spinner({ label }) {
  return (
    <span className="inline-flex items-center gap-2 text-sm font-medium text-ink-soft">
      <span className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-ink/20 border-t-emerald" aria-hidden="true" />
      {label || 'Working…'}
    </span>
  );
}

function ScoreRing({ score }) {
  const r = 54;
  const c = 2 * Math.PI * r;
  const color = scoreColor(score);
  return (
    <div className="flex flex-col items-center">
      <svg viewBox="0 0 140 140" className="h-36 w-36" role="img" aria-label={`Overall score ${score} out of 100`}>
        <circle cx="70" cy="70" r={r} fill="none" stroke="#EDE9DF" strokeWidth="12" />
        <circle
          cx="70" cy="70" r={r} fill="none" stroke={color} strokeWidth="12"
          strokeLinecap="round" strokeDasharray={c}
          strokeDashoffset={c - (c * Math.max(0, Math.min(100, score))) / 100}
          transform="rotate(-90 70 70)"
        />
        <text x="70" y="68" textAnchor="middle" fontSize="30" fontWeight="700" fill="#0F1E33" fontFamily="Fraunces, serif">{score}</text>
        <text x="70" y="90" textAnchor="middle" fontSize="12" fill="#64748B">/ 100</text>
      </svg>
      <span className="mt-1 text-sm font-semibold" style={{ color }}>{scoreLabel(score)}</span>
    </div>
  );
}

function SectionBar({ name, data }) {
  const [open, setOpen] = useState(false);
  const color = scoreColor(data.score);
  return (
    <div className="rounded-xl border border-ink/10 bg-white px-4 py-3">
      <button type="button" onClick={() => setOpen(!open)} className="flex w-full items-center justify-between gap-3 text-left">
        <span className="font-semibold capitalize text-ink">{name}</span>
        <span className="text-sm font-bold" style={{ color }}>{data.score}/100</span>
      </button>
      <div className="mt-2 h-2 overflow-hidden rounded-full bg-sand">
        <div className="h-full rounded-full transition-all" style={{ width: `${data.score}%`, background: color }} />
      </div>
      {open && (
        <ul className="mt-3 space-y-1.5">
          {(data.tips || []).map((t, i) => (
            <li key={i} className="flex gap-2 text-sm text-ink-soft">
              <span className="mt-0.5 text-emerald" aria-hidden="true">✦</span><span>{t}</span>
            </li>
          ))}
        </ul>
      )}
      <button type="button" onClick={() => setOpen(!open)} className="mt-2 text-xs font-semibold text-emerald-dark hover:underline">
        {open ? 'Hide fix tips' : 'Show fix tips'}
      </button>
    </div>
  );
}

/* ---------------- main tool ---------------- */

export default function ResumeTool() {
  const [resumeText, setResumeText] = useState('');
  const [fileName, setFileName] = useState('');
  const [fileNote, setFileNote] = useState('');
  const [role, setRole] = useState(ROLES[0]);
  const [parsing, setParsing] = useState(false);

  const [analyzing, setAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState(null);
  const [error, setError] = useState('');

  const [jdText, setJdText] = useState('');
  const [jdLoading, setJdLoading] = useState(false);
  const [jdResult, setJdResult] = useState(null);

  const [rewrites, setRewrites] = useState({});
  const [copied, setCopied] = useState('');

  const [prevScore, setPrevScore] = useState(null);

  const [hlName, setHlName] = useState('');
  const [hlRole, setHlRole] = useState('');
  const [hlSkills, setHlSkills] = useState('');
  const [hlLoading, setHlLoading] = useState(false);
  const [headlines, setHeadlines] = useState([]);

  const [showPreview, setShowPreview] = useState(false);
  const fileRef = useRef(null);

  useEffect(() => {
    try {
      const v = localStorage.getItem('rezscore_last');
      if (v) setPrevScore(JSON.parse(v));
    } catch (e) { /* ignore */ }
  }, []);

  function flashCopied(key) {
    setCopied(key);
    setTimeout(() => setCopied(''), 1600);
  }

  async function handleFile(e) {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    setError('');
    setFileNote('');
    const name = file.name.toLowerCase();
    setParsing(true);
    try {
      const buf = await file.arrayBuffer();
      let text = '';
      let note = '';
      if (name.endsWith('.pdf')) {
        text = await extractPdf(buf);
        note = 'PDF parsed in your browser. Note: PDFs can hide tables and graphics from ATS parsers — DOCX is the safest format.';
      } else if (name.endsWith('.docx')) {
        text = await extractDocx(buf);
        note = 'DOCX parsed in your browser — the safest format for ATS systems.';
      } else if (name.endsWith('.txt')) {
        text = await file.text();
      } else {
        throw new Error('Please upload a PDF, DOCX or TXT file — or paste your resume text below.');
      }
      text = text.replace(/\s+\n/g, '\n').trim();
      if (text.length < 80) throw new Error('We could not read enough text from this file. Try pasting your resume text instead.');
      setResumeText(text);
      setFileName(file.name);
      setFileNote(note);
      setAnalysis(null);
      setJdResult(null);
    } catch (err) {
      setError(err.message || 'Could not read that file.');
    } finally {
      setParsing(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  }

  function heuristicFormatChecks() {
    const issues = [];
    if (/[✦★►▶❖✧❀➤➢☛☞]/.test(resumeText)) {
      issues.push({ issue: 'Decorative Unicode symbols detected', severity: 'medium', fix: 'Replace fancy bullets and symbols with simple dashes or standard bullets (•). Some ATS parsers turn them into garbage characters.' });
    }
    if (fileName.toLowerCase().endsWith('.pdf')) {
      issues.push({ issue: 'PDF layout risks', severity: 'medium', fix: 'PDFs can contain invisible tables, text boxes and multi-column layouts that scramble reading order. Export as DOCX for maximum ATS safety.' });
    }
    const longLines = resumeText.split('\n').filter((l) => l.length > 220).length;
    if (longLines > 3) {
      issues.push({ issue: 'Very long unbroken lines found', severity: 'low', fix: 'Break dense paragraphs into short bullet points. ATS parsers and recruiters both skim — bullets win.' });
    }
    return issues;
  }

  async function analyzeResume() {
    if (resumeText.trim().length < 80) {
      setError('Please upload or paste your resume first (at least a few lines).');
      return;
    }
    setError('');
    setAnalyzing(true);
    try {
      const prompt =
`You are an expert ATS (Applicant Tracking System) resume auditor. The candidate is applying for this role: ${role}.

Analyze the resume text below strictly. Return ONLY valid JSON — no markdown, no code fences, no commentary. Use exactly this shape:
{
  "overall": <integer 0-100>,
  "summary": "<2-sentence overall verdict>",
  "sections": {
    "contact": {"score": <0-100>, "tips": ["tip", "tip"]},
    "summary": {"score": <0-100>, "tips": ["tip", "tip"]},
    "experience": {"score": <0-100>, "tips": ["tip", "tip"]},
    "skills": {"score": <0-100>, "tips": ["tip", "tip"]},
    "education": {"score": <0-100>, "tips": ["tip", "tip"]}
  },
  "weakBullets": ["<exact weak bullet text from resume>", ... up to 8],
  "metricsMissing": ["<exact bullet text that lacks numbers/percentages>", ... up to 8],
  "formattingIssues": [{"issue": "...", "severity": "high|medium|low", "fix": "..."}],
  "atsNotes": ["short note", "short note"]
}
Rules: be strict and realistic like a real ATS. Missing sections score below 30. Vague bullets without metrics go in metricsMissing. Copy bullet text EXACTLY as written in the resume.

Resume text:
"""${resumeText.slice(0, 12000)}"""`;
      const content = await callGroq(prompt);
      const data = parseJson(content);
      if (typeof data.overall !== 'number' || !data.sections) throw new Error('Unexpected AI response format. Please try again.');
      setAnalysis(data);
      setRewrites({});
      try {
        const last = localStorage.getItem('rezscore_last');
        if (last) setPrevScore(JSON.parse(last));
        localStorage.setItem('rezscore_last', JSON.stringify({ score: data.overall, at: Date.now() }));
      } catch (e) { /* ignore */ }
      document.getElementById('rezscore-results')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } catch (err) {
      setError(err.message || 'Analysis failed. Please try again.');
    } finally {
      setAnalyzing(false);
    }
  }

  async function checkJD() {
    if (resumeText.trim().length < 80) { setError('Add your resume first.'); return; }
    if (jdText.trim().length < 40) { setError('Paste the job description first (at least a few lines).'); return; }
    setError('');
    setJdLoading(true);
    try {
      const prompt =
`You are an ATS keyword-matching engine. Compare the RESUME against the JOB DESCRIPTION for a ${role} role.
Return ONLY valid JSON — no markdown, no commentary:
{
  "matchScore": <integer 0-100>,
  "missingKeywords": ["keyword/phrase from JD absent in resume", ... up to 12],
  "foundKeywords": ["keyword present in both", ... up to 12],
  "tips": ["actionable tip to close the gap", "tip"]
}
Be strict: only count a keyword as found if it clearly appears in the resume.

RESUME:
"""${resumeText.slice(0, 9000)}"""

JOB DESCRIPTION:
"""${jdText.slice(0, 6000)}"""`;
      const content = await callGroq(prompt);
      const data = parseJson(content);
      if (typeof data.matchScore !== 'number') throw new Error('Unexpected AI response format. Please try again.');
      setJdResult(data);
    } catch (err) {
      setError(err.message || 'JD check failed. Please try again.');
    } finally {
      setJdLoading(false);
    }
  }

  async function rewriteBullet(idx, bullet) {
    setRewrites((r) => ({ ...r, [idx]: { loading: true, text: '' } }));
    try {
      const prompt =
`Rewrite this resume bullet point to be strong, specific and ATS-friendly for a ${role} role. Start with a powerful action verb, keep it under 25 words, and add a placeholder like [X%] or [$Y] where a metric belongs if none is given. Return ONLY the rewritten bullet — no quotes, no commentary.\n\nBullet: ${bullet}`;
      const text = (await callGroq(prompt)).trim();
      setRewrites((r) => ({ ...r, [idx]: { loading: false, text } }));
    } catch (err) {
      setRewrites((r) => ({ ...r, [idx]: { loading: false, text: '', error: 'Rewrite failed — try again.' } }));
    }
  }

  async function generateHeadlines() {
    if (!hlRole.trim()) { setError('Tell us your target role for the headline generator.'); return; }
    setError('');
    setHlLoading(true);
    try {
      const prompt =
`Generate 5 punchy LinkedIn headlines for: Name: ${hlName || 'Professional'} | Target role: ${hlRole} | Key skills: ${hlSkills || 'not specified'}.
Rules: each under 200 characters, keyword-rich for recruiter search, no emojis overload. Return ONLY a JSON array of 5 strings, e.g. ["...", "..."].`;
      const content = await callGroq(prompt);
      const arr = parseJsonArray(content);
      setHeadlines(arr.slice(0, 5));
    } catch (err) {
      setError(err.message || 'Headline generation failed. Please try again.');
    } finally {
      setHlLoading(false);
    }
  }

  function downloadReport() {
    if (!analysis) return;
    const lines = [
      'RezScore ATS Report', `Role: ${role}`, `Overall: ${analysis.overall}/100`, '',
      ...Object.entries(analysis.sections).map(([k, v]) => `${k.toUpperCase()}: ${v.score}/100 — ${(v.tips || []).join(' | ')}`),
      '', 'Missing metrics:', ...(analysis.metricsMissing || []).map((b) => '- ' + b),
      '', 'Formatting issues:', ...(analysis.formattingIssues || []).map((f) => `- [${f.severity}] ${f.issue} — Fix: ${f.fix}`),
    ];
    const blob = new Blob([lines.join('\n')], { type: 'text/plain' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'rezscore-ats-report.txt';
    a.click();
    URL.revokeObjectURL(a.href);
  }

  const delta = prevScore && analysis && prevScore.score !== analysis.overall
    ? analysis.overall - prevScore.score : null;

  return (
    <div className="w-full">
      {/* ---------- INPUT CARD ---------- */}
      <div className="rounded-2xl border border-ink/10 bg-white p-5 shadow-card sm:p-8">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="font-display text-2xl font-bold">Check your resume</h2>
          <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-light px-3 py-1.5 text-xs font-bold uppercase tracking-wide text-emerald-dark">
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M2 6.5l2.6 2.6L10 3.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
            100% Free • No Signup
          </span>
        </div>

        <div className="mt-5 grid gap-5 md:grid-cols-2">
          <div>
            <label className="mb-1.5 block text-sm font-semibold">Target role</label>
            <select value={role} onChange={(e) => setRole(e.target.value)} className="w-full rounded-xl border border-ink/15 bg-cream px-3.5 py-2.5 text-sm font-medium outline-none focus:border-emerald focus:ring-2 focus:ring-emerald/20">
              {ROLES.map((r) => <option key={r} value={r}>{r}</option>)}
            </select>
          </div>
          <div>
            <label className="mb-1.5 block text-sm font-semibold">Upload resume</label>
            <div className="flex gap-2">
              <input ref={fileRef} type="file" accept=".pdf,.docx,.txt" onChange={handleFile} className="hidden" id="rezscore-file" />
              <label htmlFor="rezscore-file" className="flex flex-1 cursor-pointer items-center justify-center gap-2 rounded-xl border-2 border-dashed border-ink/20 bg-cream px-3.5 py-2.5 text-sm font-semibold text-ink-soft transition hover:border-emerald hover:text-ink">
                {parsing ? <Spinner label="Reading file…" /> : (<><svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M8 10V2M5 5l3-3 3 3M3 12v2h10v-2" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/></svg> PDF / DOCX / TXT</>)}
              </label>
            </div>
            {fileName && <p className="mt-1.5 truncate text-xs text-ink-faint">Attached: <span className="font-semibold text-ink">{fileName}</span></p>}
          </div>
        </div>

        <div className="mt-4">
          <label htmlFor="rezscore-text" className="mb-1.5 block text-sm font-semibold">Or paste resume text</label>
          <textarea
            id="rezscore-text" rows={8} value={resumeText}
            onInput={(e) => { setResumeText(e.target.value); setFileName(''); setFileNote(''); }}
            placeholder="Paste your full resume text here…"
            className="w-full rounded-xl border border-ink/15 bg-cream px-3.5 py-3 font-mono text-[13px] leading-relaxed outline-none focus:border-emerald focus:ring-2 focus:ring-emerald/20"
          />
          <div className="mt-1 flex items-center justify-between text-xs text-ink-faint">
            <span>{resumeText.length.toLocaleString()} characters</span>
            {fileNote && <span className="max-w-[60%] text-right">{fileNote}</span>}
          </div>
        </div>

        {error && (
          <div className="mt-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-medium text-red-700" role="alert">
            {error}
          </div>
        )}

        <div className="mt-5 flex flex-wrap items-center gap-3">
          <button
            type="button" onClick={analyzeResume} disabled={analyzing}
            className="rounded-xl bg-ink px-7 py-3 text-sm font-bold text-cream shadow-card transition hover:bg-ink-soft disabled:opacity-60"
          >
            {analyzing ? <Spinner label="Analyzing resume…" /> : 'Analyze My Resume'}
          </button>
          <p className="flex items-center gap-1.5 text-xs text-ink-faint">
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><rect x="2.5" y="6" width="9" height="6" rx="1.5" stroke="currentColor" strokeWidth="1.4"/><path d="M5 6V4.5a2 2 0 014 0V6" stroke="currentColor" strokeWidth="1.4"/></svg>
            Checked in your browser. Nothing uploaded or stored. No signup.
          </p>
        </div>
      </div>

      {/* ---------- RESULTS ---------- */}
      {analysis && (
        <div id="rezscore-results" className="mt-8 scroll-mt-24">
          <div className="rounded-2xl border border-ink/10 bg-white p-5 shadow-card sm:p-8">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <h2 className="font-display text-2xl font-bold">Your ATS report</h2>
              <div className="flex gap-2">
                <button type="button" onClick={() => copyText(`My RezScore ATS result: ${analysis.overall}/100 for ${role}. ${analysis.summary}`, () => flashCopied('score'))} className="rounded-lg border border-ink/15 px-3.5 py-2 text-xs font-bold text-ink transition hover:border-emerald hover:text-emerald-dark">
                  {copied === 'score' ? 'Copied!' : 'Copy score'}
                </button>
                <button type="button" onClick={downloadReport} className="rounded-lg border border-ink/15 px-3.5 py-2 text-xs font-bold text-ink transition hover:border-emerald hover:text-emerald-dark">
                  Download report
                </button>
              </div>
            </div>

            <div className="mt-6 flex flex-col items-center gap-6 md:flex-row md:items-start">
              <ScoreRing score={analysis.overall} />
              <div className="flex-1">
                <p className="text-[15px] leading-relaxed text-ink-soft">{analysis.summary}</p>
                {delta !== null && (
                  <p className={`mt-2 inline-block rounded-full px-3 py-1 text-xs font-bold ${delta >= 0 ? 'bg-emerald-light text-emerald-dark' : 'bg-red-50 text-red-700'}`}>
                    {delta >= 0 ? `▲ +${delta}` : `▼ ${delta}`} vs your last check
                  </p>
                )}
                <button type="button" onClick={() => setShowPreview(!showPreview)} className="mt-3 block text-sm font-semibold text-emerald-dark hover:underline">
                  {showPreview ? 'Hide ATS parse preview' : 'Show how an ATS reads your resume →'}
                </button>
              </div>
            </div>

            {showPreview && (
              <div className="mt-4 rounded-xl border border-ink/10 bg-ink p-4">
                <p className="mb-2 text-xs font-bold uppercase tracking-widest text-cream/60">ATS plain-text view — graphics, tables & columns stripped</p>
                <pre className="max-h-64 overflow-auto whitespace-pre-wrap font-mono text-xs leading-relaxed text-cream/90">{resumeText.slice(0, 4000)}</pre>
              </div>
            )}

            <h3 className="mt-8 font-display text-xl font-bold">Section-wise scores</h3>
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              {Object.entries(analysis.sections).map(([k, v]) => <SectionBar key={k} name={k} data={v} />)}
            </div>

            {(analysis.formattingIssues?.length > 0 || heuristicFormatChecks().length > 0) && (
              <div className="mt-8">
                <h3 className="font-display text-xl font-bold">Formatting killers detected</h3>
                <div className="mt-3 space-y-2.5">
                  {[...(analysis.formattingIssues || []), ...heuristicFormatChecks()].map((f, i) => (
                    <div key={i} className={`rounded-xl border px-4 py-3 ${f.severity === 'high' ? 'border-red-300 bg-red-50' : f.severity === 'medium' ? 'border-amber-300 bg-amber-50' : 'border-ink/10 bg-cream'}`}>
                      <p className="flex items-center gap-2 text-sm font-bold">
                        <span className={`inline-block h-2.5 w-2.5 rounded-full ${f.severity === 'high' ? 'bg-red-600' : f.severity === 'medium' ? 'bg-amber-500' : 'bg-ink-faint'}`} aria-hidden="true" />
                        <span className={f.severity === 'high' ? 'text-red-800' : 'text-ink'}>{f.issue}</span>
                      </p>
                      <p className="mt-1 text-sm text-ink-soft"><span className="font-semibold">Fix:</span> {f.fix}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {analysis.metricsMissing?.length > 0 && (
              <div className="mt-8">
                <h3 className="font-display text-xl font-bold">Bullets missing numbers <span className="text-sm font-body font-medium text-ink-faint">(recruiters love metrics)</span></h3>
                <ul className="mt-3 space-y-2">
                  {analysis.metricsMissing.map((b, i) => (
                    <li key={i} className="flex items-start justify-between gap-3 rounded-xl bg-sand/70 px-4 py-2.5 text-sm">
                      <span className="text-ink-soft">“{b}”</span>
                      <button type="button" onClick={() => copyText(b, () => flashCopied('m' + i))} className="shrink-0 text-xs font-bold text-emerald-dark hover:underline">
                        {copied === 'm' + i ? 'Copied!' : 'Copy'}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {analysis.weakBullets?.length > 0 && (
              <div className="mt-8">
                <h3 className="font-display text-xl font-bold">Weak bullets — one-click AI rewrite</h3>
                <div className="mt-3 space-y-3">
                  {analysis.weakBullets.map((b, i) => {
                    const rw = rewrites[i] || {};
                    return (
                      <div key={i} className="rounded-xl border border-ink/10 bg-white px-4 py-3">
                        <p className="text-sm text-ink-soft">“{b}”</p>
                        <div className="mt-2 flex flex-wrap gap-2">
                          <button type="button" onClick={() => rewriteBullet(i, b)} disabled={rw.loading} className="rounded-lg bg-emerald px-3.5 py-1.5 text-xs font-bold text-white transition hover:bg-emerald-dark disabled:opacity-60">
                            {rw.loading ? <Spinner label="Rewriting…" /> : '✦ Rewrite with AI'}
                          </button>
                          {rw.text && (
                            <button type="button" onClick={() => copyText(rw.text, () => flashCopied('r' + i))} className="rounded-lg border border-ink/15 px-3.5 py-1.5 text-xs font-bold hover:border-emerald">
                              {copied === 'r' + i ? 'Copied!' : 'Copy rewrite'}
                            </button>
                          )}
                        </div>
                        {rw.text && <p className="mt-2 rounded-lg bg-emerald-light px-3 py-2 text-sm font-medium text-ink">{rw.text}</p>}
                        {rw.error && <p className="mt-2 text-xs font-semibold text-red-600">{rw.error}</p>}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {analysis.atsNotes?.length > 0 && (
              <div className="mt-8 rounded-xl bg-ink p-5 text-cream">
                <h3 className="font-display text-lg font-bold">ATS insider notes</h3>
                <ul className="mt-2 space-y-1.5 text-sm text-cream/85">
                  {analysis.atsNotes.map((n, i) => <li key={i} className="flex gap-2"><span className="text-emerald">✦</span><span>{n}</span></li>)}
                </ul>
              </div>
            )}
          </div>

          {/* ---------- JD MATCH ---------- */}
          <div className="mt-8 rounded-2xl border border-ink/10 bg-white p-5 shadow-card sm:p-8">
            <h2 className="font-display text-2xl font-bold">Job description match</h2>
            <p className="mt-1 text-sm text-ink-soft">Paste the job posting. We compare it against your resume and show your match score plus the exact keywords you're missing.</p>
            <label htmlFor="rezscore-jd" className="mb-1.5 mt-4 block text-sm font-semibold">Job description</label>
            <textarea id="rezscore-jd" rows={6} value={jdText} onInput={(e) => setJdText(e.target.value)} placeholder="Paste the job description here…" className="w-full rounded-xl border border-ink/15 bg-cream px-3.5 py-3 text-sm leading-relaxed outline-none focus:border-emerald focus:ring-2 focus:ring-emerald/20" />
            <button type="button" onClick={checkJD} disabled={jdLoading} className="mt-3 rounded-xl bg-ink px-6 py-2.5 text-sm font-bold text-cream transition hover:bg-ink-soft disabled:opacity-60">
              {jdLoading ? <Spinner label="Matching…" /> : 'Check JD Match'}
            </button>
            {jdResult && (
              <div className="mt-5 rounded-xl border border-ink/10 bg-cream p-4">
                <div className="flex items-center gap-3">
                  <span className="font-display text-4xl font-bold" style={{ color: scoreColor(jdResult.matchScore) }}>{jdResult.matchScore}%</span>
                  <span className="text-sm font-semibold text-ink-soft">keyword match with this job</span>
                  <button type="button" onClick={() => copyText(`JD match: ${jdResult.matchScore}%. Missing: ${(jdResult.missingKeywords || []).join(', ')}`, () => flashCopied('jd'))} className="ml-auto rounded-lg border border-ink/15 bg-white px-3 py-1.5 text-xs font-bold hover:border-emerald">
                    {copied === 'jd' ? 'Copied!' : 'Copy'}
                  </button>
                </div>
                {jdResult.missingKeywords?.length > 0 && (
                  <div className="mt-3">
                    <p className="text-xs font-bold uppercase tracking-wide text-red-700">Missing keywords — add these</p>
                    <div className="mt-1.5 flex flex-wrap gap-1.5">
                      {jdResult.missingKeywords.map((k, i) => <span key={i} className="rounded-full bg-red-100 px-2.5 py-1 text-xs font-semibold text-red-800">{k}</span>)}
                    </div>
                  </div>
                )}
                {jdResult.foundKeywords?.length > 0 && (
                  <div className="mt-3">
                    <p className="text-xs font-bold uppercase tracking-wide text-emerald-dark">Already covered</p>
                    <div className="mt-1.5 flex flex-wrap gap-1.5">
                      {jdResult.foundKeywords.map((k, i) => <span key={i} className="rounded-full bg-emerald-light px-2.5 py-1 text-xs font-semibold text-emerald-dark">{k}</span>)}
                    </div>
                  </div>
                )}
                {jdResult.tips?.length > 0 && (
                  <ul className="mt-3 space-y-1 text-sm text-ink-soft">
                    {jdResult.tips.map((t, i) => <li key={i} className="flex gap-2"><span className="text-emerald">✦</span><span>{t}</span></li>)}
                  </ul>
                )}
              </div>
            )}
          </div>

          {/* ---------- LINKEDIN HEADLINES ---------- */}
          <div className="mt-8 rounded-2xl border border-ink/10 bg-white p-5 shadow-card sm:p-8">
            <h2 className="font-display text-2xl font-bold">Bonus: LinkedIn headline generator</h2>
            <p className="mt-1 text-sm text-ink-soft">Free bonus tool — 92% of recruiters search LinkedIn by headline keywords.</p>
            <div className="mt-4 grid gap-3 sm:grid-cols-3">
              <div>
                <label className="mb-1 block text-xs font-bold uppercase tracking-wide text-ink-faint" htmlFor="hl-name">Name (optional)</label>
                <input id="hl-name" value={hlName} onInput={(e) => setHlName(e.target.value)} placeholder="Aarav Sharma" className="w-full rounded-xl border border-ink/15 bg-cream px-3 py-2.5 text-sm outline-none focus:border-emerald" />
              </div>
              <div>
                <label className="mb-1 block text-xs font-bold uppercase tracking-wide text-ink-faint" htmlFor="hl-role">Target role</label>
                <input id="hl-role" value={hlRole} onInput={(e) => setHlRole(e.target.value)} placeholder="Data Analyst" className="w-full rounded-xl border border-ink/15 bg-cream px-3 py-2.5 text-sm outline-none focus:border-emerald" />
              </div>
              <div>
                <label className="mb-1 block text-xs font-bold uppercase tracking-wide text-ink-faint" htmlFor="hl-skills">Key skills</label>
                <input id="hl-skills" value={hlSkills} onInput={(e) => setHlSkills(e.target.value)} placeholder="SQL, Python, Tableau" className="w-full rounded-xl border border-ink/15 bg-cream px-3 py-2.5 text-sm outline-none focus:border-emerald" />
              </div>
            </div>
            <button type="button" onClick={generateHeadlines} disabled={hlLoading} className="mt-3 rounded-xl bg-emerald px-6 py-2.5 text-sm font-bold text-white transition hover:bg-emerald-dark disabled:opacity-60">
              {hlLoading ? <Spinner label="Writing…" /> : 'Generate 5 Headlines'}
            </button>
            {headlines.length > 0 && (
              <ul className="mt-4 space-y-2">
                {headlines.map((h, i) => (
                  <li key={i} className="flex items-start justify-between gap-3 rounded-xl bg-cream px-4 py-2.5 text-sm font-medium">
                    <span>{h}</span>
                    <button type="button" onClick={() => copyText(h, () => flashCopied('h' + i))} className="shrink-0 text-xs font-bold text-emerald-dark hover:underline">
                      {copied === 'h' + i ? 'Copied!' : 'Copy'}
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
