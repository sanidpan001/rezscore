/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        cream: '#FAF9F6',
        sand: '#F1EDE4',
        ink: {
          DEFAULT: '#0F1E33',
          soft: '#334155',
          faint: '#64748B',
        },
        emerald: {
          DEFAULT: '#0E9F6E',
          dark: '#0B7A56',
          light: '#E6F6EF',
        },
        clay: '#C2410C',
        gold: '#B45309',
      },
      fontFamily: {
        display: ['Fraunces', 'Georgia', '"Times New Roman"', 'serif'],
        body: ['Inter', 'system-ui', '-apple-system', 'sans-serif'],
      },
      boxShadow: {
        card: '0 1px 2px rgba(15,30,51,0.06), 0 10px 30px -14px rgba(15,30,51,0.14)',
        lift: '0 2px 4px rgba(15,30,51,0.08), 0 18px 44px -16px rgba(15,30,51,0.22)',
      },
    },
  },
  plugins: [],
};
